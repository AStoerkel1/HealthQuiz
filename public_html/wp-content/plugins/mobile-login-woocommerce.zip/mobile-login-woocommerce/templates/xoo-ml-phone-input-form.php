<form class="xoo-ml-phone-form">
	<?php echo $phone_input; ?>
	<button type="submit" class="button xoo-ml-phone-form-btn"> <?php _e( 'Verify Phone Number', 'mobile-login-woocommerce' ); ?></button>
</form>